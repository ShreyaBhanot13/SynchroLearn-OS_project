# Deadlocak-Synchronization-os

Build a website for Deadlock and Synchronisation Algorithms of OS. And try to display their solution into Animations and Visualization for better understanding.  

try it @ https://jaypatel1210.github.io/Deadlocak-Synchronization-os/  
